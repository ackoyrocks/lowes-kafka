package com.micro.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Component
@RestController
@EnableAutoConfiguration

public class GlobalLimitController {

		@Autowired
	private LimitConfig limitConfig;
		
		
		@RequestMapping("/pixelService")
		public String healthCheck() {
			return "PixelService OK";
		}
		
		@GetMapping("/pixelService/globalLimit")
		public String getGlobalLimit() throws Exception {
			RateLimiter rateLimiter = new RateLimiter(limitConfig.getLimit(),limitConfig.getGranularity());
			//RateLimiter rateLimiter = new RateLimiter(10.0f,10000.0f);
			return rateLimiter.canAdd();
			
			
		}
		
		@PostMapping(value="/pixelService/globalLimit")
		public String postGlobalLimit() throws Exception {
			RateLimiter rateLimiter = new RateLimiter(limitConfig.getLimit(),limitConfig.getGranularity());
			//RateLimiter rateLimiter = new RateLimiter(20.0f,60000.0f);
			return rateLimiter.canAdd();
		}
		
	}

