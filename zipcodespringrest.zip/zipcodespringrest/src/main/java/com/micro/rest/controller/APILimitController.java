package com.micro.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class APILimitController {

		@Autowired
		private LimitConfig limitConfig; // same auto wire can be used to inject dependecy as done in Global Limit Controller Class
		
//		@Autowired
//		private RateLimiter rateLimiter;
		
		@RequestMapping("/api")
		public String healthCheck() {
			return "OK";
		}
		
		@GetMapping("/apiLimit/createPixel")
		public String getApiLimit() throws Exception {
			RateLimiter rateLimiter = new RateLimiter(limitConfig.getLimit(),limitConfig.getGranularity());
			//RateLimiter rateLimiter = new RateLimiter(10.0f,1000.0f);
			return rateLimiter.canAdd();
			
		}
		
		@PostMapping(value="/apiLimit/createPixel")
		@ResponseBody
		public String postApiLimit(@RequestBody LimitConfig limitConfig) throws Exception {
			RateLimiter rateLimiter = new RateLimiter(limitConfig.getLimit(),limitConfig.getGranularity());
			//RateLimiter rateLimiter = new RateLimiter(20.0f,60000.0f);
			return rateLimiter.canAdd();
		}
		
		
		@PutMapping(value="/apiLimit/createPixel")
		public String putApiLimit() throws Exception {
			RateLimiter rateLimiter = new RateLimiter(limitConfig.getLimit(),limitConfig.getGranularity());
			//RateLimiter rateLimiter = new RateLimiter(10.0f,60000.0f*60);
			return rateLimiter.canAdd();
		}
		
		@GetMapping("/apiLimit/getPixel")
		public String getAPILimitgetPixel() throws Exception {
			RateLimiter rateLimiter = new RateLimiter(limitConfig.getLimit(),limitConfig.getGranularity());
			//RateLimiter rateLimiter = new RateLimiter(5.0f,1000.0f);
			return rateLimiter.canAdd();
			
		}
		
		@PostMapping(value="/apiLimit/getPixel")
		public String postAPILimitgetPixel() throws Exception {
			RateLimiter rateLimiter = new RateLimiter(limitConfig.getLimit(),limitConfig.getGranularity());
			//RateLimiter rateLimiter = new RateLimiter(20.0f,60000.0f);
			return rateLimiter.canAdd();
		}
		
	}

