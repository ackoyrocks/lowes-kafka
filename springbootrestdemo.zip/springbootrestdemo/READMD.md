
Import as maven project and run the SpringBootDemoApplication.java

Example : 
localhost:8080/pixelService/globalLimit

GET /pixelService/globalLimit/ - 10/sec returns if Within rate limit  or not.
POST /pixelService/globalLimit/ - 20/min similar for others as above
GET /apiLimit/createPixel/ - 5/sec similar for others as above
POST /apiLimit/createPixel/ - 20/min similar for others as above
PUT /apiLimit/createPixel/ - 10/hr similar for others above
GET /apiLimit/getPixel/ - 5/sec similar for others as above
POST /apiLimit/getPixel/ - 20/min similar for others as above


