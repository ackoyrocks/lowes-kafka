package com.micro.rest;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan({"com.micro.rest.controller", "com.micro.rest"})

@SpringBootApplication 
public class SpringBootDemoApplication {
	
    public static void main(String[] args) throws Exception {
    
        SpringApplication.run(SpringBootDemoApplication.class, args);
        
        
    }
    
}
