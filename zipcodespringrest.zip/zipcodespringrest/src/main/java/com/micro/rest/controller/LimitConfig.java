package com.micro.rest.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class LimitConfig {

    public LimitConfig() {

    }

    public LimitConfig(float limit, float granularity) {
        super();
        this.limit = limit;
        this.granularity = granularity;
        
    }
    @Value( "${granularity.limit}" )
    private float granularity;
    
    @Value( "${rate.limit}" )
	private float limit;
	
    public float getLimit() {
		return limit;
	}

	public void setLimit(float limit) {
		this.limit = limit;
	}

	public float getGranularity() {
		return granularity;
	}

	public void setGranularity(float granularity) {
		this.granularity = granularity;
	}



	
    
	
    
}