package com.micro.rest.controller;

public class RateLimiter {
	
	protected float maxRate;
    protected long minTime;
    protected float interval;
    
    //holds time of last action (past or future!)
    protected long lastSchedAction = System.currentTimeMillis();

    public RateLimiter(float maxRate, float interval) throws Exception {
        if(maxRate <= 0.0f) {
            throw new Exception("Invalid rate");
        }
        this.maxRate = maxRate;
        this.minTime = (long)(interval / maxRate);
        this.interval = interval ;
    }
  // @Bean
    public String canAdd() throws InterruptedException {
        long curTime = System.currentTimeMillis();
        long timeLeft;

        //calculate when can we do the action
        synchronized(this) {
        	System.out.println("lastSchedAction =" + lastSchedAction);
        	System.out.println("minTime =" + minTime);
       	System.out.println("curTime =" + curTime);
            timeLeft = lastSchedAction + minTime - curTime;
            System.out.println("timeLeft =" + timeLeft);
            
            if(timeLeft > 0) {
                lastSchedAction += minTime;
                //System.out.println("lastSchedAction =" + lastSchedAction);
                
               // System.out.println("curTime =" + curTime);
                
            }
            else {
                lastSchedAction = curTime;
            }
        }

        //If needed, wait for our time
        if(timeLeft <= 0) {
            return "Rate limit Exceeded";

        }
        else {
        	
            Thread.sleep(timeLeft);
            
        }
        float insec = interval/1000;
        String noOfReq= "Within rate limit with maximum " + maxRate + " request(s) per " + insec + " seconds" ;
		return noOfReq ;
    }
}
